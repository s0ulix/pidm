# Pyidm

This python module help you to download content with multiple parallel threads. So your download speed may increase.